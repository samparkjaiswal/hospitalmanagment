$(document).ready(function() {
    $('#register').on('submit', function(e) {
        e.preventDefault();
        var name = $('#Name').val();
        var email = $('#Email').val();
        var password = $('#Password').val();
         var csrf_token = $("#csrf").val();

        //   var da =  $('meta[name="_token"]').attr('content')



        $.ajax({
            type: "POST",
            url: 'http://127.0.0.1:8000/reg',

            // url: base_url + 'reg',  //call globally url

            data: {
                "name":name,
                "email":email,
                "password": password,
                "_token" : csrf_token
            },
            success: function (result) {
               console.log(result);

              $('#msg').removeClass('d-none');   //this code is used for show msg on page and reset the form data
            //   $('#msg').prepend(result.success);  //for display cut button
            //    $('#msg').html(result.success);   //success is key name which pass in controller in response method

            $('#msg #msgshow').html(result.success);   //msg display for in field custom for close button

               $('#register')[0].reset();

            //    $('#msg').html('Registration Success');   //worked better but not bettter approach

            //    location.reload(true);  //worked but not better approach

            },
            error: function (error) {
                console.log(error)

                $('#msgdiv').removeClass('d-none');

                $('#msg').html(result.error);
                $('#register')[0].reset();


            }



        });


    });

    $('#closebtn').on('click', function() {    //custome create for msg display for close button
        $(this).parent().addClass('d-none');
    })
})

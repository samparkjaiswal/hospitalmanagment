<!doctype html>
<html lang="en">
  <head>
    <title>Registration Page</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    {{-- <meta name="_token" id= "csrf" content="{{ csrf_token() }}"> --}}


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    {{-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> --}}
{{--
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script> --}}



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"> </script>






    {{-- <script>
        const base_url = "{{ env('APP_URL') }}";   //for set globally url
    </script> --}}




  </head>
  <body>




    <div class="container">
        <div class="row">

            <div class="col-md-12">

            <h2 style="color:red;font-weight:bold;text-decoration:underline">Registration From Ajax</h2>



            <input type="hidden" name="_token" id="csrf" value="{{ csrf_token() }}">

            <br>

            {{-- <div class="alert alert-success alert-dismissible fade show  d-none " id="msg" role="alert">   <!--  this code for msg show  -->
              <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>  <!-- work perfect -->
          </div> --}}


         <div class="alert alert-success d-none " id="msg" role="alert">   <!-- custome create by me -->
          <span id="msgshow"></span>
              <button type="button" class="close" id="closebtn"  aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>




          {{-- <div class="alert alert-success d-none" id="msg">
            <button type="button" class="close" data-bs-dismiss="alert">x</button>  <!--customer create-->
            </div> --}}

          {{-- <div class="alert alert-success alert-dismissible fade show d-none" id="msg" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">  <!--change here 'data-dismiss' to 'data-bs-dismiss'-->
              <span aria-hidden="true">*</span>
            </button>
          </div> --}}


            {{-- @if (Session::get('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
            @endif

            @if (Session::get('fail'))
            <div class="alert alert-danger">
                {{ Session::get('fail') }}
            </div>
            @endif --}}

        <form autocomplete="off" id="register" method="post">

            <div class="form-group">
              <label for="">Name</label>
              <input type="text" class="form-control" name="name" id="Name" aria-describedby="helpId" placeholder="">
                <span></span>
            </div>

            <div class="form-group">
                <label for="">Email</label>
                <input type="text" class="form-control" name="email" id="Email" aria-describedby="helpId" placeholder="">
                  <span></span>
              </div>

              <div class="form-group">
                <label for="">Password</label>
                <input type="text" class="form-control" name="password" id="Password" aria-describedby="helpId" placeholder="">
                  <span></span>
              </div>

              <button class="btn btn-success" id="">Register</button>

            </form>

        </div>

        </div>
    </div>

    <script src="{{asset('crudjs/regi.js') }}"></script>

  </body>
</html>

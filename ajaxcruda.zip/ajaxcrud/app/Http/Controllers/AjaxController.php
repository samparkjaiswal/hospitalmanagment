<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class AjaxController extends Controller
{
    public function formview()
    {
        return view('Register');
    }

    public function insert(Request $request)
    {


        $student = new Student();

        $student->name = $request->name;
        $student->email = $request->email;
        $student->password = $request->password;

        $student->save();

        if($student)
        {

        //   $status =  $request->session()->flash('success', 'Registration successful!'); //its work when we reload the page via ajax(but not better approach)


            return response()->json(['success' => 'Registration success'], 200);  //best way to return response with msg

            // return $student; //worked but not better approach

            // return response()->json($student);  //worked better but not better approach

        }
        else
        {
            // $status =  $request->session()->flash('fail', 'Something error!, try after sometimes.');


            return response()->json(['error' => 'something went wrong!'], 400);

        }
        // return response()->json($status);

    }


    
}

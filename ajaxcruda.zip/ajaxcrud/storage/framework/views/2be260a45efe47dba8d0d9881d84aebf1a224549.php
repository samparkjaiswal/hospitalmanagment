<!doctype html>
<html lang="en">
  <head>
    <title>Registration Page</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"> </script>






    




  </head>
  <body>




    <div class="container">
        <div class="row">

            <div class="col-md-12">

            <h2 style="color:red;font-weight:bold;text-decoration:underline">Registration From Ajax</h2>



            <input type="hidden" name="_token" id="csrf" value="<?php echo e(csrf_token()); ?>">

            <br>

            


         <div class="alert alert-success d-none " id="msg" role="alert">

          <span id="msgshow"></span>
              <button type="button" class="close" id="closebtn"  aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>




          

          


            

        <form autocomplete="off" id="register" method="post">

            <div class="form-group">
              <label for="">Name</label>
              <input type="text" class="form-control" name="name" id="Name" aria-describedby="helpId" placeholder="">
                <span></span>
            </div>

            <div class="form-group">
                <label for="">Email</label>
                <input type="text" class="form-control" name="email" id="Email" aria-describedby="helpId" placeholder="">
                  <span></span>
              </div>

              <div class="form-group">
                <label for="">Password</label>
                <input type="text" class="form-control" name="password" id="Password" aria-describedby="helpId" placeholder="">
                  <span></span>
              </div>

              <button class="btn btn-success" id="">Register</button>

            </form>

        </div>

        </div>
    </div>

    <script src="<?php echo e(asset('crudjs/regi.js')); ?>"></script>

  </body>
</html>
<?php /**PATH /opt/lampp/htdocs/ajaxcrud/resources/views/Register.blade.php ENDPATH**/ ?>